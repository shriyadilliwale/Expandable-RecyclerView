package com.example.myapplication

import android.content.Context
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.ViewHolder

import java.io.File


class PreviousResults : RecyclerView.Adapter<PreviousResults.ViewHolder>(){

    private val itemTitles = arrayOf("Armyworm","Aphids","Cutworm")
    private val itemDetails1 = arrayOf("Delivered: 20/01/2021","Delivered: 20/01/2021","Delivered: 20/01/2021")
    private val itemDetails2 = arrayOf("Result: 14/11/2000","Result: 14/11/2000","Result: 14/11/2000")
    private val itemImages = intArrayOf(
        R.drawable.image_1,
        R.drawable.image_2,
        R.drawable.image_3
    )

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var image: ImageView
        var textTitle: TextView
        var textDes1: TextView
        var textDes2: TextView

        init {
            image = itemView.findViewById(R.id.image1)
            textTitle = itemView.findViewById(R.id.pest_title)
            textDes1 = itemView.findViewById(R.id.pest_label)
            textDes2 = itemView.findViewById(R.id.pest_date)
        }
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int):ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.previous_results, parent, false)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.textTitle.text= itemTitles[position]
        holder.textDes1.text= itemDetails1[position]
        holder.textDes2.text= itemDetails2[position]
        holder.image.setImageResource(itemImages[position])



        holder.itemView.setOnClickListener{
                v:View -> Toast.makeText(v.context,"Clicked on the item",Toast.LENGTH_SHORT).show()
        }
    }

    override fun getItemCount(): Int {
        return itemTitles.size
    }


}