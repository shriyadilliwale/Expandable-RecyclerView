package com.example.myapplication


import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.recyclerview.widget.RecyclerView


class ImageAdapter : RecyclerView.Adapter<ImageAdapter.ViewHolder>(){

    private val itemTitles = arrayOf("What is this that i found yesterday? ")
    private val itemDetails1 = arrayOf("Delivered On")
    private val itemDetails2 = arrayOf("14/11/2020")
    private val itemImages1 = intArrayOf(
        R.drawable.image_1,
    )
//    private val itemImages2 = intArrayOf(
//        R.drawable.image_2,
//    )
//    private val itemImages3 = intArrayOf(
//        R.drawable.image_3,
//    )
//    private val itemImages4 = intArrayOf(
//        R.drawable.image_4,
//    )



    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var image1: ImageView
        var textTitle: TextView
        var textDes1: TextView
        var textDes2: TextView

        init {
            image1 = itemView.findViewById<ImageView>(R.id.image1)
            textTitle = itemView.findViewById(R.id.pest_title)
            textDes1 = itemView.findViewById(R.id.pest_label)
            textDes2 = itemView.findViewById(R.id.pest_date)
        }
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.raw_image_selection, parent, false)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.textTitle.text= itemTitles[position]
        holder.textDes1.text= itemDetails1[position]
        holder.textDes2.text= itemDetails2[position]
        holder.image1.setImageResource(itemImages1[position])


    }

    override fun getItemCount(): Int {
        return itemTitles.size
    }


}
//class ImageAdapter(val versionList: List<Expandable>) :
//        RecyclerView.Adapter<ImageAdapter.ViewHolder>(){
//    class ViewHolder (itemView: View) : RecyclerView.ViewHolder(itemView){
//
//        var image1: ImageView = itemView.findViewById<ImageView>(R.id.image1)
//        var image2: ImageView = itemView.findViewById<ImageView>(R.id.image2)
//        var image3: ImageView = itemView.findViewById<ImageView>(R.id.image3)
//        var image4: ImageView = itemView.findViewById<ImageView>(R.id.image1)
//        var pestTitle: TextView = itemView.findViewById(R.id.pest_title)
//        var pestLabel: TextView = itemView.findViewById(R.id.pest_label)
//        var pestDate: TextView = itemView.findViewById(R.id.pest_date)
//        var linearlayout: LinearLayout = itemView.findViewById(R.id.linear_layout)
//        var expandablelayout: RelativeLayout = itemView.findViewById(R.id.expandable_layout)
//
//    }
//
//    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
//        val view = LayoutInflater.from(parent.context).inflate(R.layout.raw_image_selection, parent, false)
//        return ViewHolder(view)
//    }
//
//    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
//        val expandables : Expandable = versionList[position]
//        holder.pestTitle.text = expandables.textTitle
//        holder.pestLabel.text = expandables.textDes1
//        holder.pestDate.text = expandables.textDes2
//        holder.image1.setImageResource(expandables.image1)
//        holder.image2.setImageResource(expandables.image2)
//        holder.image3.setImageResource(expandables.image3)
//        holder.image4.setImageResource(expandables.image4)
//
//        val isExpandable : Boolean = versionList[position].expandable
//        holder.expandablelayout.visibility = if (isExpandable) View.VISIBLE else View.GONE
//
//        holder.linearlayout.setOnClickListener {
//            val expandables = versionList[position]
//            expandables.expandable = !expandables.expandable
//            notifyItemChanged(position)
//        }
//    }
//
//    override fun getItemCount(): Int {
//        return versionList.size
//    }
//}
