package com.example.myapplication

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Typeface
import android.os.Build
import android.util.DisplayMetrics
import android.util.TypedValue
import android.view.*
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.imageview.ShapeableImageView
import kotlinx.android.synthetic.main.activity_main.view.*
import kotlinx.android.synthetic.main.previous_results.view.*
import kotlinx.android.synthetic.main.raw_image_selection.view.*
import kotlinx.android.synthetic.main.raw_image_selection.view.image1

class RVAdapter(private val versionList: List<Expandable>) :
        RecyclerView.Adapter<RVAdapter.ViewHolder>(){

     class ViewHolder (itemView: View) : RecyclerView.ViewHolder(itemView){



        var imagenew1: ImageView = itemView.findViewById<ImageView>(R.id.imagenew1)
        var imagenew2: ImageView = itemView.findViewById<ImageView>(R.id.imagenew2)
        var imagenew3: ImageView = itemView.findViewById<ImageView>(R.id.imagenew3)


        var linearlayout: LinearLayout = itemView.findViewById(R.id.linearLayout)
        var expandablelayout: RelativeLayout = itemView.findViewById(R.id.expand_layout)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {

        val view = LayoutInflater.from(parent.context).inflate(R.layout.raw_image_selection, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder:ViewHolder, position: Int) {
        val expandables : Expandable = versionList[position]

        holder.imagenew1.setImageResource(expandables.imagenew1)
        holder.imagenew2.setImageResource(expandables.imagenew2)
        holder.imagenew3.setImageResource(expandables.imagenew3)


        val isExpandable : Boolean = versionList[position].expandable
        holder.expandablelayout.visibility = if (isExpandable) View.VISIBLE else View.GONE

        holder.linearlayout.setOnClickListener {
            val expandables = versionList[position]
            expandables.expandable = !expandables.expandable
            notifyItemChanged(position)
        }
    }

    override fun getItemCount(): Int {
        return versionList.size
    }



}



//class RVAdapter : RecyclerView.Adapter<RVAdapter.ViewHolder>() {
//    private val itemImages2 = intArrayOf(
//        R.drawable.image_1,
//    )
//    private val itemImages3 = intArrayOf(
//        R.drawable.image_2,
//    )
//    private val itemImages4 = intArrayOf(
//        R.drawable.image_3,
//    )
//    private val itemImages5 = intArrayOf(
//        R.drawable.image_4,
//    )
//
//    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
//        var imagenew1: ImageView
//        var imagenew2: ImageView
//        var imagenew3: ImageView
//
//
//        init {
//            imagenew1 = itemView.findViewById<ImageView>(R.id.imagenew1)
//            imagenew2 = itemView.findViewById<ImageView>(R.id.imagenew2)
//            imagenew3 = itemView.findViewById<ImageView>(R.id.imagenew3)
//
//        }
//
//        var recyclerViewimg: RecyclerView = itemView.findViewById(R.id.recyclerView)
//        var imagenew1img: ShapeableImageView = itemView.findViewById(R.id.imagenew1)
//        var imagenew2img: ShapeableImageView = itemView.findViewById(R.id.imagenew2)
//        var imagenew3img: ShapeableImageView = itemView.findViewById(R.id.imagenew3)
//        var linearlayout: LinearLayout = itemView.findViewById(R.id.expand_layout)
//        var expandableLayout: RecyclerView = itemView.findViewById(R.id.expandable)
//
//
//    }
//
//
//    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DataModelVH {
//        val view: View = LayoutInflater.from(parent.context).inflate(R.layout.raw_image_selection,parent,false)
//        return DataModelVH(view)
//    }
//
//    override fun onBindViewHolder(holder: DataModelVH, position: Int) {
////        val datamodel: DataModel= datamodelList[position]
////        holder.imagenew1img.imageAlpha=datamodel.imageNew1
////        holder.imagenew2img.imageAlpha=datamodel.imageNew2
////        holder.imagenew3img.setImageResource(itemImages1[position])
//
//        holder.imagenew1.setImageResource(itemImages2[position])
//
//        val isExpandable:Boolean=datamodelList[position].exp
//        holder.expandableLayout.visibility=if (isExpandable) View.VISIBLE else View.GONE
//
//        holder.linearlayout.setOnClickListener {
//            val datamodel = datamodelList[position]
//            datamodel.exp = !datamodel.exp
//            notifyItemChanged(position)
//        }
//
//    }
//
//    override fun getItemCount(): Int {
//       return datamodelList.size
//    }
//
//}

//    private lateinit var context: Context
//
//    private val itemImages1 = intArrayOf(
//        R.drawable.image_1,
//    )
//
//    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)
//
//    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
//        context = parent.context
//        val v = LayoutInflater.from(parent.context).inflate(R.layout.raw_image_selection, parent, false)
//        return ViewHolder(v)
//    }
//
//    override fun getItemCount(): Int {
//        return itemsCells.size
//    }
//
//
//
//    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
//        // Add data to cells
//        holder.itemView.recyclerView.addView= (itemsCells[position]).question
//        holder.itemView.scrollview.text= (itemsCells[position]).answer
//
//
//        // Set the height in answer TextView
//        holder.itemView.scrollview.layoutParams.height = expandedSize[position]
//
//        // Expand/Collapse the answer TextView when you tap on the question TextView
//        holder.itemView.recyclerView.setOnClickListener {
//            if (expandedSize[position] == 0) {
//                // Calculate the height of the Answer Text
//                val answerTextViewHeight = height(
//                    context,
//                    itemsCells[position].answer,
//                    Typeface.DEFAULT,
//                    16,
//                    dp2px(15f, context)
//                )
//                changeViewSizeWithAnimation(holder.itemView.imagenew1, answerTextViewHeight, 300L)
//                expandedSize[position] = answerTextViewHeight
//            } else {
//                changeViewSizeWithAnimation(holder.itemView.scrollview, 0, 300L)
//                expandedSize[position] = 0
//            }
//        }
//
//
//    }
//
//
//    private fun changeViewSizeWithAnimation(view: View, viewSize: Int, duration: Long) {
//        val startViewSize = view.measuredHeight
//        val endViewSize: Int =
//            if (viewSize < startViewSize) (viewSize) else (view.measuredHeight + viewSize)
//        val valueAnimator =
//            ValueAnimator.ofInt(startViewSize, endViewSize)
//        valueAnimator.duration = duration
//        valueAnimator.addUpdateListener {
//            val animatedValue = valueAnimator.animatedValue as Int
//            val layoutParams = view.layoutParams
//            layoutParams.height = animatedValue
//            view.layoutParams = layoutParams
//        }
//        valueAnimator.start()
//    }
//
//    private fun height(context: Context, text: String, typeface: Typeface?, textSize: Int, padding: Int): Int {
//        val textView = TextView(context)
//        textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, textSize.toFloat())
//        textView.setPadding(padding, padding, padding, padding)
//        textView.typeface = typeface
//        textView.text = text
//        val mMeasureSpecWidth =
//            View.MeasureSpec.makeMeasureSpec(getDeviceWidth(context), View.MeasureSpec.AT_MOST)
//        val mMeasureSpecHeight = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
//        textView.measure(mMeasureSpecWidth, mMeasureSpecHeight)
//        return textView.measuredHeight
//    }
//
//    private fun dp2px(dpValue: Float, context: Context): Int {
//        val scale = context.resources.displayMetrics.density
//        return (dpValue * scale + 0.5f).toInt()
//    }
//
//    private fun getDeviceWidth(context: Context): Int {
//        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
//            val displayMetrics = DisplayMetrics()
//            val display: Display? = context.display
//            display?.getRealMetrics(displayMetrics)
//            displayMetrics.widthPixels
//        } else {
//            val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
//            val displayMetrics = DisplayMetrics()
//            wm.defaultDisplay.getMetrics(displayMetrics)
//            displayMetrics.widthPixels
//        }
//    }
//}
