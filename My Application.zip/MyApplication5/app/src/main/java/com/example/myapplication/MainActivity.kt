package com.example.myapplication

import android.graphics.BitmapFactory
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.R
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_main.recyclerView
import java.io.IOException
import java.io.InputStream
import java.util.ArrayList

class MainActivity : AppCompatActivity(), View.OnClickListener{


    private val versionList = ArrayList<Expandable>()

    private var layoutManager: RecyclerView.LayoutManager? = null
    private var adapter: RecyclerView.Adapter<ImageAdapter.ViewHolder>? = null
    private var adapter1: RecyclerView.Adapter<PreviousResults.ViewHolder>? = null

    lateinit var imageV:ImageView
    var button: Button? = null
    var tophone = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

//     try{
//          var imageV:ImageView=findViewById(R.id.image1)
//     }catch(ignored:NullPointerException){}

        imageV= findViewById<View>(R.id.image1) as ImageView

        layoutManager = LinearLayoutManager(this)
        recyclerView.layoutManager = layoutManager
        adapter = ImageAdapter()
        recyclerView.adapter = adapter



        initData()
        setRecyclerView()

        layoutManager = LinearLayoutManager(this)
        recyclerView1.layoutManager = layoutManager
        adapter1 = PreviousResults()
        recyclerView1.adapter = adapter1



        setSupportActionBar(toolbar)
        toolbar.setNavigationOnClickListener {
            Toast.makeText(applicationContext, "Success", Toast.LENGTH_SHORT).show()
        }


        //tophone = R.drawable.ic_launcher

        val imagine1:ImageView = findViewById<View>(R.id.imagenew1) as ImageView
        val imagine2 = findViewById<View>(R.id.imagenew2) as ImageView
        val imagine3 = findViewById<View>(R.id.imagenew3) as ImageView

        button = findViewById<View>(R.id.button) as Button
        imagine1.setOnClickListener(this)
        imagine2.setOnClickListener(this)
        imagine3.setOnClickListener(this)

        button!!.setOnClickListener(this)

    }
     private fun setRecyclerView() {
            val rvAdapter = RVAdapter(versionList)
            recyclerView.adapter = rvAdapter
            recyclerView.setHasFixedSize(true)
        }

    private fun initData() {
        versionList.add(
            Expandable(
                R.drawable.image_1,
                R.drawable.image_2,
                R.drawable.image_3,
            )
        )

    }

//    private fun setRecyclerView() {
//        val imageAdapter = ImageAdapter(versionList)
//        recyclerView.adapter = imageAdapter
//        recyclerView.setHasFixedSize(true)
//    }
//
//    private fun initData() {
//        versionList.add(Expandable(
//            R.drawable.image_1,
//            R.drawable.image_2,
//            R.drawable.image_3,
//            R.drawable.image_4,
//            "What is this that i found yesterday?",
//            "Delivered On",
//            "14/11/2020"
//        ))
//    }

        override fun onCreateOptionsMenu(menu: Menu?): Boolean {
            menuInflater.inflate(R.menu.toolbar, menu)
            return true
        }

        override fun onOptionsItemSelected(item: MenuItem): Boolean {
            var itemview = item.itemId

            when (itemview) {
                R.id.search -> Toast.makeText(applicationContext, "Success", Toast.LENGTH_SHORT)
                    .show()
                R.id.camera -> Toast.makeText(applicationContext, "Success", Toast.LENGTH_SHORT)
                    .show()
            }
            return false

        }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.imagenew1 -> {

                imageV!!.setImageResource(R.drawable.image_1)
                tophone = R.drawable.image_1
            }
            R.id.imagenew2 -> {

                imageV!!.setImageResource(R.drawable.image_2)
                tophone = R.drawable.image_2
            }
            R.id.imagenew3 -> {

                imageV!!.setImageResource(R.drawable.image_3)
                tophone = R.drawable.image_3
            }
//            R.id.imageView5 -> {
//                imageView1!!.setImageResource(R.drawable.image2)
//                tophone = R.drawable.ic_launcher
//            }
//            R.id.imageView6 -> {
//                imageView1!!.setImageResource(R.drawable.image6)
//                tophone = R.drawable.ic_launcher
//            }
//            R.id.imageView7 -> {
//                imageView1!!.setImageResource(R.drawable.image7)
//                tophone = R.drawable.ic_launcher
//            }
            R.id.button -> {
                val a: InputStream = resources.openRawResource(tophone)
                val whatever = BitmapFactory.decodeStream(a)
                try {
                    applicationContext.setWallpaper(whatever)
                } catch (e: IOException) {
                    e.printStackTrace()
                }
            }
        }
    }



    }