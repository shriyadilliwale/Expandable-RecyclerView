package com.example.myapplication

import android.media.Image

class Expandable (val imagenew1: Int,
                  val imagenew2: Int,
                  val imagenew3: Int,

                  var expandable: Boolean = false){
}