package com.example.myapplication

class DataModel(val imageNew1: Int,val imageNew2: Int, val imageNew3: Int, var exp:Boolean=false){

}
